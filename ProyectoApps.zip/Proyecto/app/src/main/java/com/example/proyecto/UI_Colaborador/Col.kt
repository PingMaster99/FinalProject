package com.example.proyecto.UI_Colaborador

class Col {
}