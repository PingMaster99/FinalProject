package com.example.proyecto.UI_Colaborador.Inscrito

import androidx.lifecycle.ViewModel

class InscritoColViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}